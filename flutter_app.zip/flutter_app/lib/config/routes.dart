import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String splash = '/splash';
  static const String login = '/login';
  static const String deliveryHome = '/delivery/home';
  static const String deliveryTaskList = '/delivery/tasks';
  static const String deliveryTaskDetail = '/delivery/task-detail';
  static const String deliveryCheckIn = '/delivery/check-in';
  static const String adminHome = '/admin/home';
  static const String adminTaskCreate = '/admin/task-create';
  static const String adminStats = '/admin/stats';
  
  static final List<GetPage> routes = [
    GetPage(
      name: splash,
      page: () => const SplashScreen(),
    ),
    // 登录路由
    GetPage(
      name: login,
      page: () => const LoginPage(),
    ),
    // 送水工路由
    GetPage(
      name: deliveryHome,
      page: () => const DeliveryHomePage(),
    ),
    GetPage(
      name: deliveryTaskList,
      page: () => const DeliveryTaskListPage(),
    ),
    GetPage(
      name: deliveryTaskDetail,
      page: () => const DeliveryTaskDetailPage(),
    ),
    GetPage(
      name: deliveryCheckIn,
      page: () => const DeliveryCheckInPage(),
    ),
    // 管理员路由
    GetPage(
      name: adminHome,
      page: () => const AdminHomePage(),
    ),
    GetPage(
      name: adminTaskCreate,
      page: () => const AdminTaskCreatePage(),
    ),
    GetPage(
      name: adminStats,
      page: () => const AdminStatsPage(),
    ),
  ];
}

// 临时导入占位符
const SplashScreen = Placeholder;
const LoginPage = Placeholder;
const DeliveryHomePage = Placeholder;
const DeliveryTaskListPage = Placeholder;
const DeliveryTaskDetailPage = Placeholder;
const DeliveryCheckInPage = Placeholder;
const AdminHomePage = Placeholder;
const AdminTaskCreatePage = Placeholder;
const AdminStatsPage = Placeholder;
