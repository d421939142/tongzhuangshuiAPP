class AppConfig {
  // API 配置
  static const String apiBaseUrl = 'http://localhost:3000/api';
  
  // 默认配置
  static const int connectTimeout = 10000; // ms
  static const int receiveTimeout = 10000; // ms
  
  // 功能开关
  static const bool enableLocationService = true;
  static const bool enableOfflineMode = true;
  static const bool enableVoiceInput = true;
  
  // 应用信息
  static const String appName = '桶装水配送管理';
  static const String appVersion = '1.0.0';
}
